(() => {
  const api = globalThis.browser ?? globalThis.chrome;
  // Each step runs at most once per this period, so a wrong password can't loop.
  const COOLDOWN_MS = 2 * 60 * 1000;
  const PASSWORD_WORD = /^(סיסמה|סיסמא|ססמה|password)$/i;

  const visible = (el) => !!el && el.getClientRects().length > 0 && !el.disabled;
  const label = (el) => (el.value || el.textContent || "").trim();
  const all = (selector) => [...document.querySelectorAll(selector)].filter(visible);

  const findButton = (pattern) =>
    all('button, input[type="submit"], input[type="button"], a[role="button"], a.btn')
      .find((b) => pattern.test(label(b)));

  function fill(input, value) {
    input.focus();
    input.value = value;
    for (const type of ["input", "keyup", "change"]) {
      input.dispatchEvent(new Event(type, { bubbles: true }));
    }
  }

  // Which of the three screens is showing, and what to do on it.
  function currentStep(username, password) {
    const passInput = all('input[type="password"]')[0];
    if (passInput) {
      const button = findButton(/^(בדיקה|check|כניסה|login)/i);
      return button && { name: "password", run: () => { fill(passInput, password); button.click(); } };
    }

    const userInput = all('input[type="text"], input[type="email"], input:not([type])')[0];
    if (userInput) {
      const button = findButton(/^(שלח|send|submit|next)/i);
      return button && { name: "username", run: () => { fill(userInput, username); button.click(); } };
    }

    // "Which way to identify?" screen: click the password card, never the SMS one.
    const card = all("h1, h2, h3, h4, h5, h6, p, span, div, button, a")
      .find((el) => PASSWORD_WORD.test(el.textContent.trim()));
    const hasSms = /מסרון|SMS/i.test(document.body.innerText);
    return card && hasSms ? { name: "method", run: () => card.click() } : null;
  }

  let busy = false;
  async function tick() {
    if (busy) return;
    busy = true;
    try {
      const { username, password, enabled = true, attempts = {} } =
        await api.storage.local.get(["username", "password", "enabled", "attempts"]);
      if (!enabled || !username || !password) return;
      const step = currentStep(username, password);
      if (!step || Date.now() - (attempts[step.name] ?? 0) < COOLDOWN_MS) return;
      await api.storage.local.set({ attempts: { ...attempts, [step.name]: Date.now() } });
      step.run();
    } finally {
      busy = false;
    }
  }

  // The steps may swap without a page reload, so keep checking for a while.
  const timer = setInterval(tick, 500);
  setTimeout(() => clearInterval(timer), 30000);
})();

const api = globalThis.browser ?? globalThis.chrome;
const $ = (id) => document.getElementById(id);

api.storage.local.get(["username", "password", "enabled"]).then((s) => {
  $("username").value = s.username ?? "";
  $("password").value = s.password ?? "";
  $("enabled").checked = s.enabled ?? true;
});

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  await api.storage.local.set({
    username: $("username").value.trim(),
    password: $("password").value,
    enabled: $("enabled").checked,
    attempts: {},
  });
  $("status").textContent = "Saved.";
});

$("enabled").addEventListener("change", () => {
  api.storage.local.set({ enabled: $("enabled").checked });
});
